#ifndef HEADER_FILE_PROTECTION
#define HEADER_FILE_PROTECTION

int install_file_protection_hooks(void);
void remove_file_protection_hooks(void);

#endif
