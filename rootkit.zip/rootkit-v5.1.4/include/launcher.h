#ifndef HEADER_LAUNCHER
#define HEADER_LAUNCHER

int launcher_start(void);
void launcher_stop(void);
int launcher_sysfs_init(void);
void launcher_sysfs_exit(void);
int launcher_is_enabled(void);

#endif /* HEADER_LAUNCHER */

