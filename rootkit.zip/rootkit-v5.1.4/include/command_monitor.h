#ifndef HEADER_COMMAND_MONITOR
#define HEADER_COMMAND_MONITOR

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/netlink.h>
#include <net/netlink.h>
#include <net/net_namespace.h>
#include <linux/skbuff.h>
#include <linux/string.h>

/* Message types sent from kernel to user-space */
#define NLMSG_HONEYPOT_ALERT   1
#define NLMSG_HONEYPOT_HEARTBEAT 2

/* Max message size */
#define HONEYPOT_MSG_MAX 512

/* Event structure sent over netlink */
struct honeypot_event {
    int type;                    /* Event type */
    pid_t pid;                   /* PID of offending process */
    pid_t ppid;                  /* Parent PID */
    uid_t uid;                   /* User ID */
    char comm[64];              /* Process name */
    char cmdline[256];          /* Full command line */
    char reason[128];           /* Why it was flagged */
    unsigned long jiffies;      /* Timestamp */
};

/* Function prototypes */
int command_monitor_init(void);
void command_monitor_exit(void);
void notify_honeypot_event(struct honeypot_event *ev);

/* Netlink socket for communication */
extern struct sock *nl_sk;

#endif /* HEADER_COMMAND_MONITOR */
