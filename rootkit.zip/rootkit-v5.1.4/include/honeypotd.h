#ifndef HEADER_HONEYPOTD_H
#define HEADER_HONEYPOTD_H

#include <linux/types.h>          /* <-- WAJIB: buat pid_t, uid_t */

/* Netlink port */
#define HONEYPOT_NETLINK_PORT  31
#define HONEYPOT_NETLINK_GROUP 1

/* Netlink message types */
#define NLMSG_HONEYPOT_ALERT     1
#define NLMSG_HONEYPOT_HEARTBEAT 2

/* Struct shared kernel <-> userspace via netlink */
struct honeypot_event {
    int type;
    pid_t pid;
    pid_t ppid;
    uid_t uid;
    char comm[64];
    char cmdline[256];
    char reason[128];
    unsigned long jiffies;
};

/* Kernel-side: process hiding */
extern int honeypotd_pid;
int  honeypotd_sysfs_init(void);
void honeypotd_sysfs_exit(void);

#endif /* HEADER_HONEYPOTD_H */
