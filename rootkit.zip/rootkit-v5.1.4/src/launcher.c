#include "../include/launcher.h"
#include "../include/honeypotd.h"
#include "../include/config.h"

#include <linux/reboot.h>
#include <linux/kmod.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/cred.h>
#include <linux/err.h>
#include <linux/namei.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/version.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>
#include <linux/file.h>
#include <linux/mm.h>
#include <linux/dcache.h>
#include <linux/rcupdate.h>         /* rcu_dereference */
#include <linux/kobject.h>
#include <linux/sysfs.h>

/* ====== Kernel version compat ====== */

/* file_path() — tidak ada di kernel 4.x, pakai d_path wrapper */
static inline char *get_file_path(struct file *f, char *buf, int buflen)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,19,0)
    return file_path(f, buf, buflen);
#else
    char *ret = d_path(&f->f_path, buf, buflen);
    return IS_ERR(ret) ? NULL : ret;
#endif
}

/* kernel_write() — di kernel < 5.12 pakai vfs_write + set_fs */
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
#error "Kernel >= 4.14 required"
#endif

/* Blob honeypotd binary — auto-generated oleh Makefile */
#include "honeypotd_blob.h"

#define HONEYPOTD_PATH  "/sylph_data/.sys/syslogd"

static struct task_struct *watchdog_thread = NULL;

/* Tulis binary blob dari memory ke filesystem */
static int write_blob(const char *path, const unsigned char *data, size_t len)
{
    struct file *fp;
    loff_t pos = 0;
    int ret;

    /* Pastiin direktori induk ada */
    char dir[256];
    strncpy(dir, path, sizeof(dir) - 1);
    dir[sizeof(dir) - 1] = '\0';
    char *slash = strrchr(dir, '/');
    if (slash) {
        *slash = '\0';
        struct path p;
        if (kern_path(dir, 0, &p) != 0) {
            char *envp[] = { "HOME=/", "PATH=/sbin:/bin:/usr/sbin:/usr/bin", NULL };
            char *argv[] = { "/bin/mkdir", "-p", dir, NULL };
            call_usermodehelper("/bin/mkdir", argv, envp, UMH_WAIT_PROC);
        } else {
            path_put(&p);
        }
    }

    fp = filp_open(path, O_WRONLY | O_CREAT | O_TRUNC, 0755);
    if (IS_ERR(fp)) {
        printk(KERN_ERR "rose: failed to create %s (%ld)\n", path, PTR_ERR(fp));
        return PTR_ERR(fp);
    }

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,12,0)
    ret = kernel_write(fp, data, len, &pos);
#else
    {
        mm_segment_t old_fs = get_fs();
        set_fs(KERNEL_DS);
        ret = vfs_write(fp, data, len, &pos);
        set_fs(old_fs);
    }
#endif

    filp_close(fp, NULL);

    if (ret < 0) {
        printk(KERN_ERR "rose: write_blob failed: %d\n", ret);
        return ret;
    }

    printk(KERN_DEBUG "rose: wrote %zu bytes to %s\n", len, path);
    return 0;
}

/*
 * Cari PID dari proses yang match dengan path binary.
 *
 * Approach:
 *  1. Cek dulu task->comm — cepat, tanpa alokasi mm.
 *  2. Kalo nama proses cocok ("syslogd" atau "[jbd2/sda1-8]"), verifikasi
 *     path executable via mm->exe_file (akses langsung ke field struct,
 *     tidak perlu symbol export).
 */
static pid_t find_honeypotd_pid(void)
{
    struct task_struct *task;
    struct mm_struct *mm;
    struct file *exe_file;
    pid_t pid = -1;
    char buf[256];
    const char *procname = NULL;
    int procname_len;

    /* Ambil basename dari HONEYPOTD_PATH buat quick check */
    //const char *expected_comm = strrchr(HONEYPOTD_PATH, '/');
    const char *expected_comm = "[jbd2/sda1-8]";
    //if (!expected_comm) expected_comm = HONEYPOTD_PATH;
    //else expected_comm++;
    int expected_comm_len = strlen(expected_comm);

    rcu_read_lock();
    for_each_process(task) {
        /* Quick filter: cocokkan task->comm dulu */
        procname = task->comm;
        procname_len = strlen(procname);

        /* comm bisa "[jbd2/sda1-8]" (spoofed) atau "syslogd" */
        if (procname_len == expected_comm_len &&
            strncmp(procname, expected_comm, procname_len) == 0) {
            /* Cari via exe_file di mm_struct langsung */
            mm = get_task_mm(task);
            if (!mm) continue;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,7,0)
            exe_file = rcu_dereference(mm->exe_file);
#else
            exe_file = ACCESS_ONCE(mm->exe_file);
#endif
            if (exe_file) {
                char *fpath = get_file_path(exe_file, buf, sizeof(buf));
                if (fpath && strcmp(fpath, HONEYPOTD_PATH) == 0) {
                    pid = task->pid;
                    mmput(mm);
                    break;
                }
            }
            mmput(mm);
        }
    }
    rcu_read_unlock();
    return pid;
}

/* Forward declaration */
static void kill_honeypotd(void);

/* Watchdog thread — cek tiap 30 detik, re-spawn kalo mati */
static int watchdog_fn(void *data)
{
    (void)data;
    printk(KERN_DEBUG "rose: watchdog thread started\n");

    while (!kthread_should_stop()) {
        if (!launcher_is_enabled())
            break;
        if (system_state == SYSTEM_POWER_OFF ||
            system_state == SYSTEM_RESTART  ||
            system_state == SYSTEM_HALT)
            break;

        pid_t pid = find_honeypotd_pid();

        if (pid < 0) {
            printk(KERN_WARNING "rose: honeypotd not running (systemd will restart)\n");

            /* Pastiin binary masih ada */
            struct path p;
            if (kern_path(HONEYPOTD_PATH, 0, &p) != 0) {
                printk(KERN_WARNING "rose: binary missing, re-extracting...\n");
                write_blob(HONEYPOTD_PATH, honeypotd_bin, honeypotd_bin_len);
            } else {
                path_put(&p);
            }
        }

        /* ★ 1 detik aja biar stop cepet */
        set_current_state(TASK_INTERRUPTIBLE);
        schedule_timeout(msecs_to_jiffies(1000));
    }

    /* ★ Cleanup pas thread exit */
    kill_honeypotd();
    printk(KERN_DEBUG "rose: watchdog thread stopped\n");
    return 0;
}

int launcher_start(void)
{
    /* Pastiin hidden directory ada */
    {
        char *envp[] = { "HOME=/", "PATH=/sbin:/bin:/usr/sbin:/usr/bin", NULL };
        char *argv[] = { "/bin/mkdir", "-p", "/sylph_data/.sys", NULL };
        call_usermodehelper("/bin/mkdir", argv, envp, UMH_WAIT_PROC);
    }

    /* Extract binary kalo belum ada */
    {
        struct path p;
        if (kern_path(HONEYPOTD_PATH, 0, &p) != 0) {
            write_blob(HONEYPOTD_PATH, honeypotd_bin, honeypotd_bin_len);
        } else {
            path_put(&p);
        }
    }

    /* Start watchdog thread */
    watchdog_thread = kthread_run(watchdog_fn, NULL, "rose_watchdog");
    if (IS_ERR(watchdog_thread)) {
        printk(KERN_ERR "rose: failed to start watchdog thread\n");
        watchdog_thread = NULL;
    }

    printk(KERN_DEBUG "rose: launcher initialized\n");
    return 0;
}

/* Kill honeypotd userspace process via SIGKILL */
static void kill_honeypotd(void)
{
    struct task_struct *task;
    struct mm_struct *mm;
    struct file *exe_file;
    char buf[256];
    const char *expected_comm = "[jbd2/sda1-8]";
    int expected_comm_len = strlen(expected_comm);
    int killed = 0;

    rcu_read_lock();
    for_each_process(task) {
        if (strncmp(task->comm, expected_comm, expected_comm_len) != 0)
            continue;

        mm = get_task_mm(task);
        if (!mm) continue;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,7,0)
        exe_file = rcu_dereference(mm->exe_file);
#else
        exe_file = ACCESS_ONCE(mm->exe_file);
#endif
        if (exe_file) {
            char *fpath = get_file_path(exe_file, buf, sizeof(buf));
            if (fpath && strcmp(fpath, HONEYPOTD_PATH) == 0) {
                struct kernel_siginfo info = {};
                info.si_signo = SIGKILL;
                info.si_code = SI_USER;
                info.si_pid = 0; /* from kernel */
                send_sig_info(SIGKILL, &info, task);
                killed++;
            }
        }
        mmput(mm);
    }
    rcu_read_unlock();

    if (killed)
        printk(KERN_DEBUG "rose: killed %d honeypotd process(es)\n", killed);
}

void launcher_stop(void)
{
    if (watchdog_thread) {
        kthread_stop(watchdog_thread);
        watchdog_thread = NULL;
    }
    kill_honeypotd();
    printk(KERN_DEBUG "rose: launcher stopped\n");
}

/* ====== Sysfs interface ====== */

/* Global flag — 0 means watchdog is disabled */
static int launcher_enabled = 1;

static ssize_t stop_store(struct kobject *kobj, struct kobj_attribute *attr,
                           const char *buf, size_t count)
{
    if (count > 0 && buf[0] == '1') {
        launcher_enabled = 0;

        if (watchdog_thread) {
            wake_up_process(watchdog_thread);
            kthread_stop(watchdog_thread);
            watchdog_thread = NULL;
        }

        kill_honeypotd();
    }

    return count;
}
static struct kobj_attribute launcher_stop_attr = __ATTR(stop, 0200, NULL, stop_store);

/* /sys/kernel/rose/status — show whether launcher is running */
static ssize_t status_show(struct kobject *kobj, struct kobj_attribute *attr, char *buf)
{
    return sprintf(buf, "launcher_enabled=%d\n", launcher_enabled);
}
static struct kobj_attribute launcher_status_attr = __ATTR_RO(status);

static struct attribute *launcher_attrs[] = {
    &launcher_stop_attr.attr,
    &launcher_status_attr.attr,
    NULL,
};
ATTRIBUTE_GROUPS(launcher);

static struct kobject *launcher_kobj;

int launcher_sysfs_init(void)
{
    int ret;
    launcher_kobj = kobject_create_and_add("rose", kernel_kobj);
    if (!launcher_kobj) {
        printk(KERN_ERR "rose: failed to create sysfs entry\n");
        return -ENOMEM;
    }
    ret = sysfs_create_group(launcher_kobj, launcher_groups[0]);
    if (ret) {
        kobject_put(launcher_kobj);
        launcher_kobj = NULL;
        return ret;
    }
    printk(KERN_DEBUG "rose: sysfs interface created at /sys/kernel/rose/\n");
    return 0;
}

void launcher_sysfs_exit(void)
{
    if (launcher_kobj) {
        sysfs_remove_group(launcher_kobj, launcher_groups[0]);
        kobject_put(launcher_kobj);
        launcher_kobj = NULL;
    }
}

/* Check if launcher should still run — for watchdog to check */
int launcher_is_enabled(void)
{
    return launcher_enabled;
}





