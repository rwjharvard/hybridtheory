#include <linux/kernel.h>
#include <linux/linkage.h>
#include <linux/ftrace.h>
#include <linux/fs.h>
#include <linux/file.h>
#include <linux/fdtable.h>
#include <linux/dcache.h>
#include <linux/path.h>
#include <linux/slab.h>
#include <linux/namei.h>
#include <linux/version.h>

#include "../include/ftrace_manager.h"
#include "../include/config.h"

/* Forward declarations biar ga kena -Wmissing-prototypes */
asmlinkage long hook_write(const struct pt_regs *regs);
asmlinkage long hook_mount(const struct pt_regs *regs);
int install_file_protection_hooks(void);
void remove_file_protection_hooks(void);

/* Original function pointers */
static asmlinkage long (*orig_write)(const struct pt_regs *);
static asmlinkage long (*orig_mount)(const struct pt_regs *);

/* ---------- HOOK WRITE ---------- */
asmlinkage long hook_write(const struct pt_regs *regs)
{
    unsigned int fd   = regs->di;
    size_t count      = regs->dx;
    struct file *file;
    char *buf_path;
    char *tmp;

    buf_path = kmalloc(PATH_MAX, GFP_KERNEL);
    if (!buf_path)
        return -ENOMEM;

    /* Pakai fget/fput — API paling stabil di semua kernel */
    file = fget(fd);
    if (file) {
        path_get(&file->f_path);
        tmp = d_path(&file->f_path, buf_path, PATH_MAX);
        path_put(&file->f_path);

        if (!IS_ERR(tmp) && strcmp(tmp, PROTECTED_FILE) == 0) {
            struct file *pf = filp_open(PROTECTED_FILE, O_WRONLY | O_CREAT, 0644);
            if (!IS_ERR(pf)) {
                kernel_write(pf, PROTECTED_CONTENT, PROTECTED_CONTENT_LEN, 0);
                filp_close(pf, NULL);
            }
            fput(file);
            kfree(buf_path);
            return count;
        }
        fput(file);
    }

    kfree(buf_path);
    return orig_write(regs);
}

/* ---------- HOOK MOUNT ---------- */
asmlinkage long hook_mount(const struct pt_regs *regs)
{
    char __user *source = (void *)regs->si;
    char __user *target = (void *)regs->di;
    char *source_buf, *target_buf;

    source_buf = kmalloc(PATH_MAX, GFP_KERNEL);
    target_buf = kmalloc(PATH_MAX, GFP_KERNEL);
    if (!source_buf || !target_buf) {
        kfree(source_buf);
        kfree(target_buf);
        return -ENOMEM;
    }

    if (copy_from_user(source_buf, source, PATH_MAX) ||
        copy_from_user(target_buf, target, PATH_MAX)) {
        kfree(source_buf);
        kfree(target_buf);
        return -EFAULT;
    }

    if (strcmp(source_buf, PROTECTED_FILE) == 0 ||
        strcmp(source_buf, "/root")         == 0 ||
        strcmp(source_buf, "/")             == 0 ||
        strcmp(target_buf, PROTECTED_FILE)  == 0 ||
        strcmp(target_buf, "/root")         == 0 ||
        strcmp(target_buf, "/")             == 0) {

        kfree(source_buf);
        kfree(target_buf);
        return 0;
    }

    kfree(source_buf);
    kfree(target_buf);
    return orig_mount(regs);
}

/* Daftar hook file protection */
static struct ftrace_hook file_hooks[] = {
    HOOK("sys_write", hook_write, &orig_write),
    HOOK("sys_mount", hook_mount, &orig_mount),
};

int install_file_protection_hooks(void)
{
    return install_hooks_set(file_hooks, ARRAY_SIZE(file_hooks));
}

void remove_file_protection_hooks(void)
{
    remove_hooks_set(file_hooks, ARRAY_SIZE(file_hooks));
}
