#include "../include/command_monitor.h"
#include "../include/config.h"
#include "../include/ftrace_manager.h"
#include "../include/utils.h"
#include <linux/uaccess.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/cred.h>
#include <linux/ctype.h>
#include <net/sock.h>
#include <net/net_namespace.h>

MODULE_LICENSE("GPL");

struct sock *nl_sk = NULL;

asmlinkage long (*orig_execve)(const struct pt_regs *);
asmlinkage int hook_execve(const struct pt_regs *regs);

/* Case-insensitive compare */
static int str_icmp(const char *a, const char *b)
{
    while (*a && *b) {
        int ca = tolower(*a);
        int cb = tolower(*b);
        if (ca != cb) return ca - cb;
        a++; b++;
    }
    return tolower(*a) - tolower(*b);
}

/* Cek apakah cmd ada di comma-separated SUSPICIOUS_CMDS */
static int cmd_in_suspicious_list(const char *cmd)
{
    const char *list = SUSPICIOUS_CMDS;
    const char *start = list;
    const char *end;
    size_t cmd_len = strlen(cmd);

    while (*start) {
        while (*start == ' ' || *start == '\t' || *start == '"')
            start++;
        end = start;
        while (*end && *end != ',')
            end++;
        size_t tok_len = end - start;
        if (tok_len > 0 && tok_len == cmd_len && strncasecmp(cmd, start, tok_len) == 0)
            return 1;
        start = end;
        if (*start == ',') start++;
    }
    return 0;
}

/* Kirim event ke userspace via netlink */
void notify_honeypot_event(struct honeypot_event *ev)
{
    struct sk_buff *skb;
    struct nlmsghdr *nlh;
    int msg_size;
    int res;

    if (!nl_sk) return;

    msg_size = sizeof(struct honeypot_event);
    skb = nlmsg_new(NLMSG_ALIGN(msg_size), GFP_ATOMIC);
    if (!skb) {
        printk(KERN_ERR "[honeypot] Failed to allocate skb\n");
        return;
    }

    nlh = nlmsg_put(skb, 0, 0, NLMSG_HONEYPOT_ALERT, msg_size, 0);
    if (!nlh) { kfree_skb(skb); return; }

    memcpy(nlmsg_data(nlh), ev, sizeof(struct honeypot_event));

    res = nlmsg_multicast(nl_sk, skb, 0, HONEYPOT_NETLINK_GROUP, GFP_ATOMIC);
    if (res < 0 && res != -ESRCH && res != -ENOBUFS)
        printk(KERN_ERR "[honeypot] nlmsg_multicast error: %d\n", res);
}

/* ftrace callback untuk sys_execve */
asmlinkage int hook_execve(const struct pt_regs *regs)
{
    struct honeypot_event ev;
    char filename[256];
    struct task_struct *task;
    int i;
    const char *p;

    task = current;
    if (!task) return orig_execve(regs);

    /* Baca filename dari regs->di */
    memset(filename, 0, sizeof(filename));
    strncpy_from_user(filename, (const char __user *)regs->di, sizeof(filename) - 1);

    /* Ambil basename aja */
    p = filename;
    for (i = 0; filename[i]; i++) {
        if (filename[i] == '/')
            p = filename + i + 1;
    }

    /* Cek apakah termasuk suspicious */
    if (!cmd_in_suspicious_list(p))
        return orig_execve(regs);

    /* Init event */
    memset(&ev, 0, sizeof(ev));
    ev.pid = task->pid;
    ev.ppid = task->parent ? task->parent->pid : 0;
    ev.uid = from_kuid(&init_user_ns, task->cred->uid);
    ev.jiffies = jiffies;
    strncpy(ev.comm, p, sizeof(ev.comm) - 1);
    strncpy(ev.cmdline, filename, sizeof(ev.cmdline) - 1);
    ev.type = 1;
    snprintf(ev.reason, sizeof(ev.reason), "Suspicious: %s", p);

    printk(KERN_DEBUG "[honeypot] ALERT: %s (PID=%d)\n", p, task->pid);
    notify_honeypot_event(&ev);

    return orig_execve(regs);
}

/* Init netlink socket */
static int init_netlink(void)
{
    struct netlink_kernel_cfg cfg = {
        .groups = HONEYPOT_NETLINK_GROUP,
        .flags = NL_CFG_F_NONROOT_RECV,
    };
    nl_sk = netlink_kernel_create(&init_net, HONEYPOT_NETLINK_PORT, &cfg);
    if (!nl_sk) {
        printk(KERN_ERR "[honeypot] Failed to create netlink socket\n");
        return -ENOMEM;
    }
    return 0;
}

static struct ftrace_hook cmd_hooks[] = {
    HOOK("sys_execve", hook_execve, &orig_execve),
};

int command_monitor_init(void)
{
    int ret;
    ret = init_netlink();
    if (ret) return ret;
    ret = install_hooks_set(cmd_hooks, ARRAY_SIZE(cmd_hooks));
    if (ret) { netlink_kernel_release(nl_sk); nl_sk = NULL; return ret; }
    printk(KERN_DEBUG "[honeypot] Command monitor initialized\n");
    return 0;
}

void command_monitor_exit(void)
{
    remove_hooks_set(cmd_hooks, ARRAY_SIZE(cmd_hooks));
    if (nl_sk) { netlink_kernel_release(nl_sk); nl_sk = NULL; }
    printk(KERN_DEBUG "[honeypot] Command monitor stopped\n");
}
