#!/bin/bash
# Uninstall Rose persistence

MODULE_NAME="rose"
MODULE_DEST="/lib/modules/$(uname -r)/kernel/drivers/misc/${MODULE_NAME}.ko"
SERVICE_NAME="rose-honeypotd.service"
SERVICE_PATH="/etc/systemd/system/${SERVICE_NAME}"
HIDDEN_DIR="/sylph_data/.sys"

# 1. Stop & disable service
systemctl stop "$SERVICE_NAME" 2>/dev/null || true
systemctl disable "$SERVICE_NAME" 2>/dev/null || true

# 2. Stop daemon
pkill -f "$HIDDEN_DIR/syslogd" 2>/dev/null || true

# 3. Unload module
rmmod "$MODULE_NAME" 2>/dev/null || true
modprobe -r "$MODULE_NAME" 2>/dev/null || true

# 4. Hapus service file (unlock dulu kalo di-chattr)
chattr -i "$SERVICE_PATH" 2>/dev/null || true
rm -f "$SERVICE_PATH"

# 5. Hapus modules-load.d
chattr -i "/etc/modules-load.d/${MODULE_NAME}.conf" 2>/dev/null || true
rm -f "/etc/modules-load.d/${MODULE_NAME}.conf"

# 6. Hapus module dari kernel tree
rm -f "$MODULE_DEST"
depmod -a

# 7. Hapus hidden directory
rm -rf "$HIDDEN_DIR"

# 8. Hapus drop-in lama (kalo ada)
rm -f /etc/systemd/system/systemd-random-seed.service.d/override.conf
rmdir /etc/systemd/system/systemd-random-seed.service.d 2>/dev/null || true

systemctl daemon-reload
echo "[+] Rose persistence removed."

