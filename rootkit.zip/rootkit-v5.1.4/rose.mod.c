#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3d49336c, "module_layout" },
	{ 0x4c2cdfe5, "kobject_put" },
	{ 0x16e4e754, "d_path" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x8f376d56, "kernel_write" },
	{ 0x236b06ba, "kmalloc_caches" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x754d539c, "strlen" },
	{ 0x5fd56cae, "ip_local_out" },
	{ 0x63026490, "unregister_kprobe" },
	{ 0x1b6314fd, "in_aton" },
	{ 0x7d0038a9, "commit_creds" },
	{ 0xfcca5424, "register_kprobe" },
	{ 0xf48a4540, "dst_release" },
	{ 0xffeedf6a, "delayed_work_timer_fn" },
	{ 0x7850314e, "filp_close" },
	{ 0xc3c42216, "init_user_ns" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0x2d5f69b3, "rcu_read_unlock_strict" },
	{ 0x9fa7184a, "cancel_delayed_work_sync" },
	{ 0xd0364716, "mmput" },
	{ 0xfb802e80, "path_get" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x8522d6bc, "strncpy_from_user" },
	{ 0xac4c4c82, "sysfs_remove_group" },
	{ 0x2d39b0a7, "kstrdup" },
	{ 0x64a99699, "kthread_create_on_node" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x8c61cd81, "kobject_create_and_add" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xbb1c1f44, "kern_path" },
	{ 0x2913637e, "from_kuid" },
	{ 0x7cb1de17, "current_task" },
	{ 0xc157ec45, "kthread_stop" },
	{ 0x2476a508, "sysfs_create_group" },
	{ 0x449ad0a7, "memcmp" },
	{ 0xedfe2d86, "get_task_mm" },
	{ 0xc4878045, "netlink_kernel_release" },
	{ 0x9166fada, "strncpy" },
	{ 0x5a921311, "strncmp" },
	{ 0xaeacf557, "kfree_skb_reason" },
	{ 0xa7eedcc4, "call_usermodehelper" },
	{ 0xc38c83b8, "mod_timer" },
	{ 0xa5a1793e, "unregister_ftrace_function" },
	{ 0x2b4a1751, "init_net" },
	{ 0x56e04324, "fput" },
	{ 0xb2c338aa, "nf_register_net_hook" },
	{ 0x117a9d11, "prepare_creds" },
	{ 0x61651be, "strcat" },
	{ 0x324445b3, "nf_unregister_net_hook" },
	{ 0xac1a55be, "unregister_reboot_notifier" },
	{ 0x6f935e35, "ftrace_set_filter_ip" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0x3dd38aca, "init_task" },
	{ 0x9f984513, "strrchr" },
	{ 0x78a82f3f, "__alloc_skb" },
	{ 0xa916b694, "strnlen" },
	{ 0x3517383e, "register_reboot_notifier" },
	{ 0x9bd5d903, "netlink_broadcast" },
	{ 0xb2fcb56d, "queue_delayed_work_on" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0x96b29254, "strncasecmp" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x481f234c, "wake_up_process" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x6d6c584a, "path_put" },
	{ 0xbfd2ca5c, "kmem_cache_alloc_trace" },
	{ 0x839a4ef8, "ip_route_output_flow" },
	{ 0x82ee90dc, "timer_delete_sync" },
	{ 0xb3f7646e, "kthread_should_stop" },
	{ 0xdc0e4855, "timer_delete" },
	{ 0xfdd9f311, "__netlink_kernel_create" },
	{ 0xc8a20060, "kernel_kobj" },
	{ 0x37a0cba, "kfree" },
	{ 0x69acdf38, "memcpy" },
	{ 0xe6a44e5f, "send_sig_info" },
	{ 0x90de72a9, "register_ftrace_function" },
	{ 0x3da069a1, "fget" },
	{ 0x15af7f4, "system_state" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xb0e602eb, "memmove" },
	{ 0xe113bbbc, "csum_partial" },
	{ 0xe3ff2c41, "get_random_u64" },
	{ 0x431f74a2, "skb_put" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xf5d61a36, "skb_copy_bits" },
	{ 0x608de63c, "__nlmsg_put" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xe914e41e, "strcpy" },
	{ 0x8d144bd9, "filp_open" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "B1175A53A3A6E0AF59F0A84");
