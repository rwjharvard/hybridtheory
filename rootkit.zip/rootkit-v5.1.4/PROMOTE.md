# 🌹 RELEASED — ROSE ROOTKIT

**Linux Kernel Level (Ring 0) Advanced Rootkit**

---

## 🎯 Fitur

- **Kernel Level Webshell** — Command execution through netfilter hook
- **Hidden Rootkit Architecture** — Self-hiding module, process, directory
- **Internal Control Panel** — Sysfs interface (`/sys/kernel/rose/`)
- **Real-Time Command Monitoring** — Hook execve, detect suspicious commands
- **ICMP Beacon** — Periodic heartbeat to C2 server
- **File Protection** — Hide specific files from userspace tools
- **Credential Manager** — Root privilege escalation via ftrace hooks
- **Launcher & Watchdog** — Auto-respawn honeypot daemon
- **Lightweight & Low Resource Usage** — Minimal kernel footprint
- **Linux Native Design** — Built for modern Linux kernels (5.x+)

---

## ✨ Fitur Utama

✅ **Berjalan langsung di Ring 0 (Kernel Space)**  
   Operasi pada privilege tertinggi, bypass semua userspace security.

✅ **Arsitektur Stealth untuk Meminimalkan Jejak Operasional**  
   - Self-hiding module (`lsmod` tidak tampilkan)
   - Process hiding (task_struct manipulation)
   - Directory hiding (filldir64 hook)
   - File protection (stat/open hook)

✅ **Command Monitoring Real-Time**  
   Hook `__x64_sys_execve` untuk deteksi aktivitas mencurigakan:
   - `lsmod`, `rmmod`, `insmod`
   - `ps`, `top`, `htop`
   - `netstat`, `ss`, `lsof`
   - `find`, `grep` pattern suspicious

✅ **ICMP Beacon untuk C2 Communication**  
   Kirim ICMP echo request berkala ke server C2 dengan payload custom.

✅ **Internal Control Panel via Sysfs**  
   ```
   /sys/kernel/rose/
   ├── status       (read: launcher status)
   ├── start        (write: enable launcher)
   └── stop         (write: disable launcher)
   ```

✅ **Launcher & Watchdog Thread**  
   - Auto-extract honeypot binary dari memory blob
   - Respawn daemon jika mati
   - Cleanup otomatis saat shutdown/reboot

✅ **Optimal untuk Penggunaan Jangka Panjang**  
   - Resource usage minimal
   - Stealth persistence via systemd + modules-load.d
   - Reboot-persistent installation

---

## 🔐 Kenapa Sulit Dihapus?

Karena **berjalan di Ring 0 (Kernel Space)**, komponen memiliki hak akses yang lebih tinggi dibanding aplikasi biasa yang berjalan di user space.

Hal ini membuat proses **analisis, penghentian, maupun penghapusan** menjadi lebih kompleks dan umumnya memerlukan:

1. **Akses administratif penuh** — Root tidak cukup, butuh kernel debugging.
2. **Analisis kernel dan modul sistem** — Reverse engineering `rose.ko`.
3. **Boot melalui media eksternal atau recovery environment** — Bypass runtime hooks.
4. **Prosedur penanganan tingkat lanjut** — Manual memory forensics, ftrace analysis.

Komponen yang berjalan pada level kernel secara umum **lebih sulit dianalisis dan dikelola** dibanding aplikasi biasa karena beroperasi pada lapisan sistem operasi dengan **hak istimewa tertinggi**.

---

## 🏗️ Arsitektur

```
┌─────────────────────────────────────┐
│   Linux Kernel Module (rose.ko)    │
├─────────────────────────────────────┤
│  Ring 0 Execution                   │
│  Kernel Space Operation             │
│  Linux Native (5.x+ compatible)     │
├─────────────────────────────────────┤
│  ┌───────────────────────────────┐  │
│  │  Ftrace Hook Manager          │  │
│  │  - sys_execve                 │  │
│  │  - sys_kill                   │  │
│  │  - sys_getdents64             │  │
│  │  - commit_creds               │  │
│  └───────────────────────────────┘  │
│  ┌───────────────────────────────┐  │
│  │  Netfilter Hook               │  │
│  │  - ICMP command shell         │  │
│  │  - C2 communication           │  │
│  └───────────────────────────────┘  │
│  ┌───────────────────────────────┐  │
│  │  Command Monitor              │  │
│  │  - Netlink socket             │  │
│  │  - Execve hook integration    │  │
│  └───────────────────────────────┘  │
│  ┌───────────────────────────────┐  │
│  │  Beacon Engine                │  │
│  │  - ICMP heartbeat timer       │  │
│  └───────────────────────────────┘  │
│  ┌───────────────────────────────┐  │
│  │  Launcher & Watchdog          │  │
│  │  - Honeypot binary blob       │  │
│  │  - Auto-respawn kthread       │  │
│  │  - Reboot notifier            │  │
│  └───────────────────────────────┘  │
└─────────────────────────────────────┘
          ↓
┌─────────────────────────────────────┐
│  Persistence Layer                  │
├─────────────────────────────────────┤
│  /lib/modules/.../rose.ko           │
│  /etc/modules-load.d/rose.conf      │
│  /etc/systemd/system/               │
│    rose-honeypotd.service           │
│  /sylph_data/.sys/syslogd           │
└─────────────────────────────────────┘
```

---

## 🎓 Para Cyber Security Antusias Pasti Suka

- **Kernel-level programming** — Belajar ftrace, netfilter, sysfs, kthread.
- **Rootkit detection techniques** — Understand how to hunt this in production.
- **Reverse engineering challenge** — Complex module structure, self-hiding mechanism.
- **Red team toolkit** — Persistence, stealth, C2 communication.
- **Blue team training** — Learn kernel forensics, memory analysis, runtime hook detection.

---

## 📦 Installation

```bash
# Build
make clean
make modules

# Install stealth persistence
sudo make stealth

# Verify
lsmod | grep rose          # (should be hidden)
systemctl status rose-honeypotd.service
cat /sys/kernel/rose/status
```

---

## 🧹 Removal

```bash
# Uninstall persistence
sudo make unstealth

# Manual cleanup (if script fails)
sudo rmmod rose
sudo rm /lib/modules/$(uname -r)/kernel/drivers/misc/rose.ko
sudo rm /etc/modules-load.d/rose.conf
sudo rm /etc/systemd/system/rose-honeypotd.service
sudo systemctl daemon-reload
sudo depmod -a
```

---

## ⚠️ Legal Notice

**FOR EDUCATIONAL AND RESEARCH PURPOSES ONLY.**

This software is designed for:
- Security research
- Penetration testing (authorized engagements)
- Educational purposes in controlled environments

**Unauthorized use on systems you do not own or have explicit permission to test is illegal.**

The authors assume no liability for misuse.

---

## 🔬 Technical Details

- **Language**: C (kernel module)
- **Target**: Linux kernel 5.x+
- **Architecture**: x86_64
- **Build system**: Kbuild (Linux kernel build system)
- **Persistence**: systemd + modules-load.d
- **Hook method**: ftrace (function tracing)
- **C2 channel**: ICMP + netlink socket

---

## 📚 Further Reading

- [Linux Kernel Module Programming Guide](https://sysprog21.github.io/lkmpg/)
- [Ftrace: The hidden light switch](https://lwn.net/Articles/370423/)
- [Netfilter Hacking HOWTO](https://www.netfilter.org/documentation/HOWTO/netfilter-hacking-HOWTO.html)
- [Rootkit detection techniques](https://www.sans.org/white-papers/1003/)

---

**Built with ❤️ by security researchers, for security researchers.**
