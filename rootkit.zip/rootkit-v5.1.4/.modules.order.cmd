cmd_/home/phenom/rootkit-v5.1.3/modules.order := {   echo /home/phenom/rootkit-v5.1.3/rose.ko; :; } | awk '!x[$$0]++' - > /home/phenom/rootkit-v5.1.3/modules.order
