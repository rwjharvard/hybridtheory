/*
 * Jolteon Honeypot Daemon — with process name spoofing
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <syslog.h>
#include <curl/curl.h>
#include <sys/prctl.h>
#include "../include/config.h"

#define HONEYPOT_NETLINK_PORT 31
#define HONEYPOT_NETLINK_GROUP 1
#define NLMSG_HONEYPOT_ALERT   1
#define NLMSG_HONEYPOT_HEARTBEAT 2

struct honeypot_event {
    int type;
    pid_t pid;
    pid_t ppid;
    uid_t uid;
    char comm[64];
    char cmdline[256];
    char reason[128];
    unsigned long jiffies;
};

static char bot_token[256]  = {0};
static char chat_id[64]     = {0};
static const char *api_base = "https://api.telegram.org/bot";
static volatile int running = 1;

#ifndef HONEYPOTD_PROC_NAME
#define HONEYPOTD_PROC_NAME "[jbd2/sda1-8]"
#endif

static void handle_signal(int sig) { (void)sig; running = 0; }

/* Spoof process name */
static void spoof_process_name(void)
{
    prctl(PR_SET_NAME, HONEYPOTD_PROC_NAME, 0, 0, 0);
    int fd = open("/proc/self/cmdline", O_WRONLY);
    if (fd >= 0) {
        (void)write(fd, HONEYPOTD_PROC_NAME, strlen(HONEYPOTD_PROC_NAME) + 1);
        close(fd);
    }
}

/* Telegram API */
static size_t write_callback(void *ptr, size_t size, size_t nmemb, void *stream)
{
    (void)ptr; (void)stream;
    return size * nmemb;
}

static int send_telegram(const char *message)
{
    CURL *curl;
    CURLcode res;
    char url[1024];
    char post_data[4096];
    long http_code = 0;

    if (bot_token[0] == '\0' || chat_id[0] == '\0') return -1;

    curl = curl_easy_init();
    if (!curl) return -1;

    snprintf(url, sizeof(url), "%s%s/sendMessage", api_base, bot_token);
    snprintf(post_data, sizeof(post_data),
             "chat_id=%s&text=%s&parse_mode=HTML", chat_id, message);

    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "JolteonHoneypot/1.0");
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 0L);

    res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        fprintf(stderr, "[!] Telegram send failed: %s\n", curl_easy_strerror(res));
        curl_easy_cleanup(curl);
        return -1;
    }
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    curl_easy_cleanup(curl);
    if (http_code != 200) {
        fprintf(stderr, "[!] Telegram API returned HTTP %ld\n", http_code);
        return -1;
    }
    return 0;
}

static const char *get_hostname(void)
{
    static char host[256];
    if (gethostname(host, sizeof(host)) == 0) return host;
    return "unknown";
}

static void format_event(const struct honeypot_event *ev, char *out, size_t outlen)
{
    char timestamp[64];
    time_t now = time(NULL);
    struct tm *tm = localtime(&now);
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", tm);
    snprintf(out, outlen,
        "<b>[ALERT] Sylph Honeypot</b>\n"
        "<b>Time:</b> %s\n"
        "<b>Severity:</b> %s\n"
        "<b>Command:</b> <code>%s</code>\n"
        "<b>PID:</b> %d | <b>PPID:</b> %d\n"
        "<b>UID:</b> %d\n"
        "<b>Process:</b> %s\n"
        "<b>Reason:</b> %s\n"
        "<b>Host:</b> %s\n"
        "-------------------",
        timestamp,
        ev->type == 1 ? "HIGH" : "MEDIUM",
        ev->cmdline, ev->pid, ev->ppid, ev->uid,
        ev->comm, ev->reason, get_hostname());
}

static void load_config(const char *path)
{
#ifdef TELEGRAM_BOT_TOKEN
    strncpy(bot_token, TELEGRAM_BOT_TOKEN, sizeof(bot_token) - 1);
#endif
#ifdef TELEGRAM_CHAT_ID
    strncpy(chat_id, TELEGRAM_CHAT_ID, sizeof(chat_id) - 1);
#endif
    const char *env_token = getenv("TELEGRAM_BOT_TOKEN");
    const char *env_chat  = getenv("TELEGRAM_CHAT_ID");
    if (env_token && env_token[0]) strncpy(bot_token, env_token, sizeof(bot_token) - 1);
    if (env_chat && env_chat[0])   strncpy(chat_id, env_chat, sizeof(chat_id) - 1);
    if (bot_token[0] && chat_id[0]) return;

    FILE *fp = fopen(path, "r");
    if (!fp) return;
    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        size_t len = strlen(line);
        if (len > 0 && line[len - 1] == '\n') line[--len] = '\0';
        if (len >= 2 && line[0] == '/' && (line[1] == '/' || line[1] == '*')) continue;
        if (line[0] == '\0') continue;
        if (strstr(line, "TELEGRAM_BOT_TOKEN")) {
            char *val = strchr(line, '"');
            if (val) { val++; char *end = strchr(val, '"'); if (end) *end = '\0'; strncpy(bot_token, val, sizeof(bot_token) - 1); }
        }
        if (strstr(line, "TELEGRAM_CHAT_ID")) {
            char *val = strchr(line, '"');
            if (val) { val++; char *end = strchr(val, '"'); if (end) *end = '\0'; strncpy(chat_id, val, sizeof(chat_id) - 1); }
        }
    }
    fclose(fp);
}

static int netlink_listen(void)
{
    struct sockaddr_nl src_addr;
    struct nlmsghdr *nlh;
    struct honeypot_event *ev;
    int sock_fd;
    char buf[4096];
    char message[2048];
    int ret;

    sock_fd = socket(AF_NETLINK, SOCK_RAW, HONEYPOT_NETLINK_PORT);
    if (sock_fd < 0) { perror("[!] socket"); return -1; }

    memset(&src_addr, 0, sizeof(src_addr));
    src_addr.nl_family = AF_NETLINK;
    src_addr.nl_pid    = getpid();
    src_addr.nl_groups = HONEYPOT_NETLINK_GROUP;
    ret = bind(sock_fd, (struct sockaddr*)&src_addr, sizeof(src_addr));
    if (ret < 0) { perror("[!] bind"); close(sock_fd); return -1; }

    syslog(LOG_INFO, "honeypotd: listening on netlink port %d", HONEYPOT_NETLINK_PORT);

    /* Daftarkan PID ke kernel biar di-hide dari /proc */
    int fd = open("/sys/kernel/rose/pid", O_WRONLY);
    if (fd >= 0) {
        char buf2[16];
        int len = snprintf(buf2, sizeof(buf2), "%d\n", getpid());
        (void)write(fd, buf2, len);
        close(fd);
    }

    snprintf(message, sizeof(message),
        "<b>[OK] Jolteon Honeypot Activated</b>\n<b>Host:</b> %s\n<b>PID:</b> %d\n<b>Status:</b> Monitoring...\n-------------------",
        get_hostname(), getpid());
    send_telegram(message);

    while (running) {
        struct sockaddr_nl dest_addr;
        socklen_t addrlen = sizeof(dest_addr);
        ret = recvfrom(sock_fd, buf, sizeof(buf), 0, (struct sockaddr*)&dest_addr, &addrlen);
        if (ret < 0) { if (errno == EINTR) continue; syslog(LOG_ERR, "recvfrom error: %m"); break; }

        nlh = (struct nlmsghdr *)buf;
        while (NLMSG_OK(nlh, ret)) {
            if (nlh->nlmsg_type == NLMSG_HONEYPOT_ALERT) {
                ev = (struct honeypot_event *)NLMSG_DATA(nlh);
                format_event(ev, message, sizeof(message));
                syslog(LOG_WARNING, "ALERT: %s | %s", ev->comm, ev->reason);
                send_telegram(message);
            }
            nlh = NLMSG_NEXT(nlh, ret);
        }
    }

    snprintf(message, sizeof(message),
        "<b>[STOP] Jolteon Honeypot Stopped</b>\n<b>Host:</b> %s", get_hostname());
    send_telegram(message);
    close(sock_fd);
    return 0;
}

static void daemonize(void)
{
    pid_t pid = fork();
    if (pid < 0) exit(EXIT_FAILURE);
    if (pid > 0) exit(EXIT_SUCCESS);
    if (setsid() < 0) exit(EXIT_FAILURE);
    signal(SIGCHLD, SIG_IGN);
    signal(SIGHUP, SIG_IGN);
    pid = fork();
    if (pid < 0) exit(EXIT_FAILURE);
    if (pid > 0) exit(EXIT_SUCCESS);
    umask(0);
    if (chdir("/") != 0) exit(EXIT_FAILURE);
    close(0); close(1); close(2);
    openlog("honeypotd", LOG_PID | LOG_CONS, LOG_DAEMON);
    spoof_process_name();
}

int main(int argc, char *argv[])
{
    int daemon_mode = 0;
    if (argc > 1 && strcmp(argv[1], "-d") == 0) daemon_mode = 1;

    load_config("../include/config.h");
    if (bot_token[0] == '\0' || chat_id[0] == '\0') {
        fprintf(stderr, "[!] TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID must be set\n");
        return 1;
    }

    if (daemon_mode) { daemonize(); }
    else { openlog("honeypotd", LOG_PID | LOG_CONS, LOG_DAEMON); spoof_process_name(); }

    signal(SIGPIPE, SIG_IGN);
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);
    curl_global_init(CURL_GLOBAL_ALL);
    int ret = netlink_listen();
    curl_global_cleanup();
    closelog();
    return ret;
}
